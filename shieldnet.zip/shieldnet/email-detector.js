// ============================================================
//  ShieldNet — email-detector.js v1.2
//  Detecta phishing en Outlook y Gmail
//  Mejorado: analiza remitente, imágenes con links, HTML oculto
// ============================================================

(function () {
  'use strict';
  if (window.__sn_email_loaded) return;
  window.__sn_email_loaded = true;

  const isGmail   = location.hostname.includes('mail.google.com');
  const isOutlook = location.hostname.includes('outlook.live.com') ||
                    location.hostname.includes('outlook.office.com');

  if (!isGmail && !isOutlook) return;

  // ── Patrones de urgencia en texto ──
  const URGENCY_PATTERNS = [
    /cuenta.{0,20}(cancelada|bloqueada|suspendida|eliminada)/i,
    /almacenamiento.{0,20}(lleno|limite|critico|agotado)/i,
    /verifica.{0,15}(ahora|inmediatamente|hoy|urgente)/i,
    /contrase[ñn]a.{0,20}(expir|venc|cambi)/i,
    /actua(liza|lice).{0,20}(datos|informaci|pago|tarjeta)/i,
    /suscripci[oó]n.{0,20}(vencid|expir|cancelad)/i,
    /archivos.{0,20}(elimin|borra|perder[aá]s)/i,
    /oferta.{0,15}(tiempo limitado|expira|[0-9]+%)/i,
    /aviso final/i, /alerta cr[ií]tica/i,
    /act[uú]a (ahora|inmediatamente)/i,
    /renueva.{0,20}(hoy|ahora|inmediatamente)/i,
    /your account.{0,20}(suspend|terminat|cancel)/i,
    /verify.{0,15}(now|immediately|today)/i,
    /storage.{0,20}(full|limit|critical)/i,
    /action required/i, /immediate action/i
  ];

  // ── Marcas legítimas y sus dominios reales ──
  const LEGIT_SENDERS = {
    'microsoft': ['microsoft.com', 'outlook.com', 'live.com', 'hotmail.com'],
    'google': ['google.com', 'gmail.com', 'googlemail.com'],
    'apple': ['apple.com', 'icloud.com'],
    'amazon': ['amazon.com', 'amazon.com.mx'],
    'dropbox': ['dropbox.com'],
    'cloud secure': ['microsoft.com', 'google.com', 'apple.com'],
    'cloud': ['microsoft.com', 'google.com', 'apple.com', 'dropbox.com']
  };

  // ── Analizar el remitente ──
  function analyzeSender(senderEmail, senderName) {
    const results = [];
    const domain = senderEmail?.split('@')[1]?.toLowerCase() || '';

    // 1. Dominio con números random = generado automáticamente
    // ej: loretta437096chung.onmicrosoft.com
    if (/[a-z]+\d{4,}[a-z]+/.test(domain)) {
      results.push({
        score: 50,
        reason: `🚨 Remitente generado automáticamente: "${senderEmail}" (patrón nombre+números)`
      });
    }

    // 2. Subdominio raro en onmicrosoft.com (tenants falsos)
    if (domain.endsWith('.onmicrosoft.com')) {
      const tenant = domain.replace('.onmicrosoft.com', '');
      if (/\d{4,}/.test(tenant) || tenant.length > 20) {
        results.push({
          score: 45,
          reason: `🚨 Tenant de Microsoft sospechoso: "${domain}" (no es una empresa real)`
        });
      }
    }

    // 3. Nombre del remitente vs dominio real
    const senderLower = (senderName + ' ' + senderEmail).toLowerCase();
    for (const [brand, legitDomains] of Object.entries(LEGIT_SENDERS)) {
      const mentionsBrand = senderLower.includes(brand);
      const isLegit = legitDomains.some(d => domain.endsWith(d));
      if (mentionsBrand && !isLegit && domain) {
        results.push({
          score: 45,
          reason: `🚨 Se hace pasar por "${brand}" pero viene de "@${domain}"`
        });
      }
    }

    // 4. TLD sospechoso en el remitente
    const badTLDs = ['.tk', '.ml', '.ga', '.cf', '.autos', '.xyz', '.sbs'];
    if (badTLDs.some(t => domain.endsWith(t))) {
      results.push({
        score: 40,
        reason: `⚠️ Dominio del remitente sospechoso: "${domain}"`
      });
    }

    return results;
  }

  // ── Analizar links (incluyendo los dentro de imágenes) ──
  function analyzeLinks(container) {
    const results = [];

    // Links normales
    const links = container.querySelectorAll('a[href]');
    let suspiciousCount = 0;

    links.forEach(link => {
      const href = link.href || '';
      try {
        const host = new URL(href).hostname;
        if (
          /\.(tk|ml|ga|cf|autos|sbs|cyou|cfd|xyz|top)$/.test(host) ||
          /[a-z]\d{4,}[a-z]/.test(host) ||   // números random en dominio
          host.split('.').length > 4 ||          // demasiados subdominios
          /\d{1,3}\.\d{1,3}\.\d{1,3}/.test(host) // IP address directo
        ) {
          suspiciousCount++;
          link.style.outline = '2px solid #ff3b6b';
          link.title = '⚠️ ShieldNet: Link sospechoso';
        }
      } catch {}
    });

    if (suspiciousCount > 0) {
      results.push({
        score: suspiciousCount * 25,
        reason: `🔗 ${suspiciousCount} enlace(s) sospechoso(s) detectado(s)`
      });
    }

    // Imágenes que son links (técnica común de phishing)
    const imgLinks = container.querySelectorAll('a[href] img, a[href] > *');
    if (imgLinks.length > 0) {
      // Si hay imágenes que funcionan como botones/links, verificar sus URLs
      let suspiciousImgLinks = 0;
      imgLinks.forEach(img => {
        const parentLink = img.closest('a');
        if (!parentLink) return;
        const href = parentLink.href || '';
        try {
          const host = new URL(href).hostname;
          if (
            /\.(autos|sbs|cyou|cfd|tk|ml|ga|cf)$/.test(host) ||
            /[a-z]\d{4,}[a-z]/.test(host)
          ) {
            suspiciousImgLinks++;
          }
        } catch {}
      });

      if (suspiciousImgLinks > 0) {
        results.push({
          score: 35,
          reason: `🖼️ Imagen usada como link sospechoso (técnica común de phishing)`
        });
      }
    }

    return results;
  }

  // ── Función principal de análisis ──
  function analyzeEmail(container, senderEmail, senderName) {
    const text = container.innerText || '';
    let totalScore = 0;
    const reasons = [];

    // 1. Analizar remitente
    const senderIssues = analyzeSender(senderEmail, senderName);
    senderIssues.forEach(({ score, reason }) => {
      totalScore += score;
      reasons.push(reason);
    });

    // 2. Patrones de urgencia en texto visible
    if (text.length > 20) {
      const found = URGENCY_PATTERNS.filter(p => p.test(text));
      if (found.length > 0) {
        totalScore += found.length * 15;
        reasons.push(`⚠️ Lenguaje de urgencia detectado (${found.length} señal/es)`);
      }
    }

    // 3. Analizar links e imágenes
    const linkIssues = analyzeLinks(container);
    linkIssues.forEach(({ score, reason }) => {
      totalScore += score;
      reasons.push(reason);
    });

    // 4. Palabras de pago
    const paymentWords = ['tarjeta', 'crédito', 'débito', 'cvv', 'nip', 'pin',
                          'credit card', 'payment', 'billing'];
    const paymentFound = paymentWords.filter(w => text.toLowerCase().includes(w));
    if (paymentFound.length >= 2) {
      totalScore += 30;
      reasons.push(`💳 Solicita información de pago`);
    }

    return {
      isPhishing: totalScore >= 60,
      isSuspicious: totalScore >= 30 && totalScore < 60,
      score: Math.min(100, totalScore),
      reasons
    };
  }

  // ── Mostrar banner ──
  function showBanner(container, analysis) {
    if (container.querySelector('.sn-email-banner')) return;

    const isPhishing = analysis.isPhishing;
    const bg = isPhishing ? '#ff3b6b' : '#d29922';
    const textColor = isPhishing ? 'white' : '#1a1a1a';

    const banner = document.createElement('div');
    banner.className = 'sn-email-banner';
    banner.style.cssText = `
      background:${bg}; color:${textColor};
      padding:12px 16px; border-radius:8px; margin:8px 0 12px;
      font-family:'Segoe UI',sans-serif; font-size:13px;
      border-left:5px solid ${isPhishing ? '#cc0033' : '#b8860b'};
      position:relative; z-index:9999;
    `;
    banner.innerHTML = `
      <div style="font-weight:700;font-size:14px;margin-bottom:6px">
        ${isPhishing ? '🚨 ShieldNet: PHISHING DETECTADO' : '⚠️ ShieldNet: Correo Sospechoso'}
        <span style="font-size:11px;margin-left:8px;opacity:0.8">Riesgo: ${analysis.score}/100</span>
      </div>
      <div style="font-size:12px;line-height:1.8">
        ${analysis.reasons.map(r => `• ${r}`).join('<br>')}
      </div>
      ${isPhishing ? `<div style="margin-top:8px;font-size:12px;font-weight:700;background:rgba(0,0,0,0.15);padding:6px 10px;border-radius:6px">
        ⛔ NO hagas clic en ningún enlace. NO ingreses datos personales ni de pago.
      </div>` : ''}
    `;

    container.insertBefore(banner, container.firstChild);
  }

  // ── Obtener remitente en Outlook ──
  function getOutlookSender() {
    const selectors = [
      '[class*="sender"] [class*="email"]',
      '[class*="FromAddress"]',
      '[aria-label*="De:"] span',
      '.customScrollBar [class*="from"]',
      'span[title*="@"]'
    ];
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el) {
        const email = el.getAttribute('title') || el.innerText || '';
        if (email.includes('@')) return email.trim();
      }
    }
    // Buscar en el DOM cualquier elemento con un email
    const allSpans = document.querySelectorAll('span, div');
    for (const el of allSpans) {
      const text = el.getAttribute('title') || '';
      if (text.includes('@') && text.includes('.') && text.length < 100) {
        return text;
      }
    }
    return '';
  }

  function getOutlookSenderName() {
    const el = document.querySelector('[class*="SenderName"], [class*="sender"] strong');
    return el?.innerText || '';
  }

  // ── Escanear Outlook ──
  function scanOutlook() {
    const bodySelectors = [
      '.allowTextSelection',
      '[class*="ReadingPaneContent"]',
      '[role="document"]',
      '.x_ReadMsgBody',
      '[class*="messageBody"]'
    ];

    for (const sel of bodySelectors) {
      const body = document.querySelector(sel);
      if (body && !body.dataset.snScanned && (body.innerText?.length > 10 || body.querySelectorAll('img').length > 0)) {
        body.dataset.snScanned = '1';
        const senderEmail = getOutlookSender();
        const senderName  = getOutlookSenderName();
        const analysis = analyzeEmail(body, senderEmail, senderName);
        if (analysis.isPhishing || analysis.isSuspicious) {
          showBanner(body.parentElement || body, analysis);
        }
        break;
      }
    }
  }

  // ── Escanear Gmail ──
  function scanGmail() {
    const body = document.querySelector('.a3s.aiL, [data-message-id] .ii.gt');
    if (!body || body.dataset.snScanned) return;
    body.dataset.snScanned = '1';

    const senderEl = document.querySelector('.gD');
    const senderEmail = senderEl?.getAttribute('email') || '';
    const senderName  = senderEl?.innerText || '';

    const analysis = analyzeEmail(body, senderEmail, senderName);
    if (analysis.isPhishing || analysis.isSuspicious) {
      showBanner(body, analysis);
    }
  }

  // ── Observer ──
  let scanTimeout;
  const observer = new MutationObserver(() => {
    clearTimeout(scanTimeout);
    scanTimeout = setTimeout(() => {
      // Limpiar flags para re-escanear correos nuevos
      document.querySelectorAll('[data-sn-scanned]').forEach(el => {
        delete el.dataset.snScanned;
      });
      if (isOutlook) scanOutlook();
      if (isGmail)   scanGmail();
    }, 900);
  });

  const start = () => {
    if (!document.body) return;
    observer.observe(document.body, { childList: true, subtree: true });
    setTimeout(() => {
      if (isOutlook) scanOutlook();
      if (isGmail)   scanGmail();
    }, 1500);
  };

  if (document.body) start();
  else document.addEventListener('DOMContentLoaded', start);

})();
