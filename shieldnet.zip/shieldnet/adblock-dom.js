// ============================================================
//  ShieldNet — adblock-dom.js
//  Elimina anuncios directamente del DOM (segunda capa)
//  Complementa las reglas declarativeNetRequest
// ============================================================

(function () {
  'use strict';
  if (window.__sn_adblock_loaded) return;
  window.__sn_adblock_loaded = true;

  // ── Selectores de contenedores de anuncios ──
  const AD_SELECTORS = [
    // Genéricos
    '[id*="ad-"]:not(body):not(html)',
    '[id*="-ad"]:not(body):not(html)',
    '[id*="ads-"]',
    '[id*="advert"]',
    '[class*="advert"]:not(body):not(html)',
    '[class*="ad-slot"]',
    '[class*="ad-unit"]',
    '[class*="ad-banner"]',
    '[class*="ad-container"]',
    '[class*="ad-wrapper"]',
    '[class*="sponsored"]',
    '[class*="promo-"]',
    '[class*="-promo"]',
    // Iframes de anuncios
    'iframe[src*="doubleclick"]',
    'iframe[src*="googlesyndication"]',
    'iframe[src*="adnxs"]',
    'iframe[src*="advertising"]',
    'iframe[src*="adserver"]',
    'iframe[src*="mediavine"]',
    'iframe[src*="adtech"]',
    'iframe[src*="aliexpress"][src*="ad"]',
    // AliExpress específico
    'iframe[src*="alicdn.com"]',
    '[class*="aliexpress-ad"]',
    // Scripts de push notifications
    'div[class*="push-notification-ad"]',
    'div[class*="in-page-push"]',
    // Anuncios nativos comunes
    '[data-ad-slot]',
    '[data-ad-client]',
    '[data-ad-unit]',
    'ins.adsbygoogle',
    // Anuncios de video intersticiales (no YouTube)
    '[class*="preroll-ad"]',
    '[class*="midroll-ad"]',
    '[id*="preroll"]',
  ];

  // ── Palabras clave en el texto del elemento (para ads nativos) ──
  // Solo aplica a divs pequeños que parecen anuncios
  const AD_TEXT_KEYWORDS = [
    'patrocinado', 'sponsored', 'publicidad', 'advertisement',
    'ad by', 'ads by', 'anuncio de'
  ];

  let removedCount = 0;

  // ── Eliminar elementos por selector ──
  function removeBySelectors() {
    AD_SELECTORS.forEach(selector => {
      try {
        document.querySelectorAll(selector).forEach(el => {
          if (isSafeToRemove(el)) {
            el.remove();
            removedCount++;
          }
        });
      } catch(e) {}
    });
  }

  // ── Eliminar elementos por texto ──
  function removeByText() {
    // Solo revisar divs pequeños tipo banner
    const smallDivs = document.querySelectorAll(
      'div[style*="position: fixed"], div[style*="position:fixed"],' +
      'div[style*="z-index: 9"], div[style*="z-index:9"]'
    );

    smallDivs.forEach(el => {
      const text = el.innerText?.toLowerCase() || '';
      const isAd = AD_TEXT_KEYWORDS.some(kw => text.includes(kw));
      if (isAd && el.offsetHeight < 300 && isSafeToRemove(el)) {
        el.remove();
        removedCount++;
      }
    });
  }

  // ── Bloquear ventanas emergentes (pop-unders) ──
  function blockPopups() {
    // Interceptar window.open para bloquear pop-ups
    const originalOpen = window.open;
    window.open = function(url, name, features) {
      // Permitir solo si fue iniciado por acción del usuario real
      if (!url || url === 'about:blank') return null;
      // Bloquear si parece ad
      if (url.includes('click') || url.includes('ad') ||
          url.includes('track') || url.includes('redir')) {
        console.log('[ShieldNet] Pop-up bloqueado:', url);
        return null;
      }
      return originalOpen.call(this, url, name, features);
    };
  }

  // ── Bloquear solicitudes de push notifications ──
  function blockPushNotifications() {
    if (!('Notification' in window)) return;
    
    const originalRequest = Notification.requestPermission;
    Notification.requestPermission = function() {
      console.log('[ShieldNet] Solicitud de notificación bloqueada');
      return Promise.resolve('denied');
    };
  }

  // ── Verificar que sea seguro eliminar el elemento ──
  function isSafeToRemove(el) {
    if (!el || !el.parentNode) return false;
    
    // No eliminar elementos del cuerpo principal
    const tag = el.tagName?.toLowerCase();
    if (['body', 'html', 'head', 'main', 'header', 'footer', 'nav', 'article'].includes(tag)) {
      return false;
    }
    
    // No eliminar si tiene mucho contenido de texto (puede ser contenido legítimo)
    const textLength = el.innerText?.length || 0;
    if (textLength > 500) return false;
    
    return true;
  }

  // ── Limpiar anuncios intersticiales (pantalla completa) ──
  function removeInterstitials() {
    // Detectar overlays de pantalla completa
    const allDivs = document.querySelectorAll('div, section');
    allDivs.forEach(el => {
      const style = window.getComputedStyle(el);
      const isFixed = style.position === 'fixed';
      const isFullScreen = parseInt(style.width) > window.innerWidth * 0.8 &&
                           parseInt(style.height) > window.innerHeight * 0.8;
      const highZ = parseInt(style.zIndex) > 1000;

      if (isFixed && isFullScreen && highZ) {
        const text = el.innerText?.toLowerCase() || '';
        const looksLikeAd = AD_TEXT_KEYWORDS.some(kw => text.includes(kw)) ||
                            el.querySelector('iframe, [id*="ad"], [class*="ad"]');
        if (looksLikeAd && isSafeToRemove(el)) {
          el.remove();
          removedCount++;
        }
      }
    });
  }

  // ── Inicializar ──
  blockPopups();
  blockPushNotifications();

  // Esperar al DOM
  function run() {
    removeBySelectors();
    removeByText();
    removeInterstitials();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', run);
  } else {
    run();
  }

  // Observar cambios dinámicos
  const observer = new MutationObserver(() => {
    removeBySelectors();
    removeInterstitials();
  });

  const startObs = () => {
    if (!document.body) return;
    observer.observe(document.body, { childList: true, subtree: true });
  };

  if (document.body) startObs();
  else document.addEventListener('DOMContentLoaded', startObs);

  // Reportar al background cuántos ads se bloquearon
  setInterval(() => {
    if (removedCount > 0) {
      chrome.runtime.sendMessage({
        type: 'ADS_REMOVED_DOM',
        count: removedCount
      }).catch(() => {});
      removedCount = 0;
    }
  }, 3000);

})();
